package com.example.pingpongstage3;
/**
 * @author R00232796
 * This program runs a game of PingPong
 * A ball will move between 2 paddles and
 * players will use the keyboard to move paddles to prevent the ball from hitting the left or right wall
 * a player will win once they score the amount of goals needed by hitting the opposite wall to their paddle
 */

import com.example.pingpongstage3.controller.BallManager;
import com.example.pingpongstage3.controller.PingPongController;
import com.example.pingpongstage3.controller.RacketKeyboardListener;
import com.example.pingpongstage3.model.Ball;
import com.example.pingpongstage3.model.Player;
import com.example.pingpongstage3.model.Racket;
import com.example.pingpongstage3.model.Resizable;
import com.example.pingpongstage3.view.PingPongCanvas;
import com.example.pingpongstage3.controller.pause;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.application.Platform;

import java.io.IOException;

/**
 * This is the application that runs the game
 */
public class PingPongApplication extends Application implements Resizable {
    // FIELDS
    public double dimensionX = 600; // width of the canvas
    public double dimensionY = 400; // height of the canvas
    public Player player1;
    public Player player2;
    public Ball ball;
    public Racket racket1;
    public Racket racket2;
    public int winningScore;

    // INITIALIZERS
    public PingPongController pingPongController = new PingPongController(this);
    PingPongMenuListener menuListener = new PingPongMenuListener(pingPongController.getApp());
    PingPongCanvas canvas = new PingPongCanvas(dimensionX, dimensionY);

    // RESIZE METHODS

    /**
     * This resizes objects through the x axis
     * @param factor: the amount that objects need to be multiplied by to adjust their size when the screen size chages
     */
    public void resizeX(double factor) {
        racket1.resizeX(factor);
        racket2.resizeX(factor);
        ball.resizeX(factor);
    }

    /**
     * This resizes objects through the x axis
     * @param factor: the amount that objects need to be multiplied by to adjust their size when the screen size chages
     */
    public void resizeY(double factor) {
        racket1.resizeY(factor);
        racket2.resizeY(factor);
        ball.resizeY(factor);
    }

    // WHAT WILL HAPPEN WHEN APP RUNS
    @Override
    /**
     * This is what runs when the program starts
     * ball: ball is set here with initial values
     * racket1 this racket will appear on the left side of the screen. The values stored are initialised here
     * racket2 this racket will appear on the right side of the screen. The values stored are initialised here
     * player1 this player controls racket1 and must score on the right side of the screen. The values stored are initialised here
     * player2 this player controls racket2 and must score on the left side of the screen. The values stored are initialised here
     */
    public void start(Stage stage) throws IOException {
        try{
            stage.setTitle("PingPong");
            ball = new Ball(this.getDimensionX()/2, this.getDimensionY()/2, 30, 1, Color.PURPLE, 3, pingPongController.app);
            racket1 = new Racket(0, this.getDimensionY()/2, 40, 30, Color.PINK);
            racket2 = new Racket(this.getDimensionX()- 40, this.getDimensionY()/2, 40, 30, Color.PURPLE);
            player1 = new Player(0, "Player1");
            player2 = new Player(0, "Player2");
            setWinningScore(3);
            canvas.drawGame(pingPongController.getApp());

            // KEYBOARD LISTENER
            RacketKeyboardListener keyboardListener = new RacketKeyboardListener(pingPongController.getApp(), canvas);
            canvas.setOnKeyPressed(keyboardListener);
            canvas.setOnKeyTyped(keyboardListener);
            canvas.setFocusTraversable(true);

            // BALL MANAGER
            BallManager ballManager= new BallManager(pingPongController.getApp(), canvas);
            Thread ballThread = new Thread(ballManager);

            ballThread.start();

            // interrupts the thread when the window is closed
            stage.setOnCloseRequest(event -> {
                ballThread.interrupt();
                Platform.exit();
            });
            Thread.yield();

            /* Menu */
            // This is where menu items are defined and given an action
            // Player name setting
            Menu PlayerMenu = new Menu("Name");
            MenuItem playerMenu1 = new MenuItem("Player 1");
            MenuItem playerMenu2 = new MenuItem("Player 2");
            playerMenu1.setOnAction(e->menuListener.setPlayer1Name());
            playerMenu2.setOnAction(e->menuListener.setPlayer2Name());

            // Speed of the ball
            Menu SpeedMenu = new Menu("Speed");
            MenuItem speedMenu1 = new MenuItem("Slow");
            MenuItem speedMenu2 = new MenuItem("Normal");
            MenuItem speedMenu3 = new MenuItem("Fast");
            speedMenu1.setOnAction(e->menuListener.setBallSpeedSlow());
            speedMenu2.setOnAction(e->menuListener.setBallSpeedNormal());
            speedMenu3.setOnAction(e->menuListener.setBallSpeedFast());

            // Racket size - this changes the height and width of the racket
            Menu RacketMenu = new Menu("Racket Size");
            MenuItem RacketMenu1 = new MenuItem("Small");
            MenuItem RacketMenu2 = new MenuItem("Medium");
            MenuItem RacketMenu3 = new MenuItem("Large");
            RacketMenu1.setOnAction(e-> menuListener.setRacketSizeSmall());
            RacketMenu2.setOnAction(e-> menuListener.setRacketSizeMedium());
            RacketMenu3.setOnAction(e-> menuListener.setRacketSizeLarge());

            // set winning score - this sets the score that needs to be reached by a player before the game ends with them winning
            Menu ScoreMenu = new Menu("Winning Score");
            MenuItem scoreMenu1 = new MenuItem("3");
            MenuItem scoreMenu2 = new MenuItem("5");
            MenuItem scoreMenu3 = new MenuItem("10");
            scoreMenu1.setOnAction(e->menuListener.setWinningScore3());
            scoreMenu2.setOnAction(e->menuListener.setWinningScore5());
            scoreMenu3.setOnAction(e->menuListener.setWinningScore10());

            // Exit - this closes the window
            Menu ExitMenu = new Menu("Exit");
            MenuItem exitMenu1 = new MenuItem("Exit");
            exitMenu1.setOnAction(e-> menuListener.setExit());

            // Speed Change - this sets how many times the speed of the ball will change throughout the game
            Menu SpeedChangeMenu = new Menu("Change Speed");
            MenuItem speedChangeMenu1 = new MenuItem("0");
            MenuItem speedChangeMenu2 = new MenuItem("3");
            MenuItem speedChangeMenu3 = new MenuItem("5");
            speedChangeMenu1.setOnAction(e->menuListener.changeBallSpeed0());
            speedChangeMenu2.setOnAction(e->menuListener.changeBallSpeed3());
            speedChangeMenu3.setOnAction(e->menuListener.changeBallSpeed5());

            // Pause the game
            Menu PauseMenu = new Menu("Pause");
            MenuItem pauseMenu1 = new MenuItem("Pause");
            MenuItem pauseMenu2 = new MenuItem("Play");
            pauseMenu1.setOnAction(e->menuListener.changeBallSpeed5());
            pauseMenu2.setOnAction(e->menuListener.changeBallSpeed5());

            // restart the game
            Menu RestartMenu = new Menu("Restart");
            MenuItem restartMenu1 = new MenuItem("Restart");
            restartMenu1.setOnAction(e->menuListener.restart());

            // adds all items into a single menu
            PlayerMenu.getItems().addAll(playerMenu1,playerMenu2);
            SpeedMenu.getItems().addAll(speedMenu1,speedMenu2,speedMenu3);
            RacketMenu.getItems().addAll(RacketMenu1,RacketMenu2,RacketMenu3);
            ScoreMenu.getItems().addAll(scoreMenu1,scoreMenu2,scoreMenu3);
            SpeedChangeMenu.getItems().addAll(speedChangeMenu1,speedChangeMenu2,speedChangeMenu3);
            PauseMenu.getItems().addAll(pauseMenu1, pauseMenu2);
            RestartMenu.getItems().addAll(restartMenu1);
            ExitMenu.getItems().addAll(exitMenu1);

            // adds all menus to one menu bar
            MenuBar menubar = new MenuBar();
            menubar.getMenus().addAll(PlayerMenu, SpeedMenu, RacketMenu, ScoreMenu, SpeedChangeMenu, PauseMenu, RestartMenu, ExitMenu);

            // LAYOUT
            // everything is added to the group
            Group root = new Group();
            VBox vbox = new VBox();
            vbox.getChildren().add(menubar);

            root.getChildren().addAll(canvas, vbox);
            Scene scene = new Scene(root);  //GROUP ROOT OF ALL

            menubar.prefWidthProperty().bind(scene.widthProperty()); // this makes the menu bar the same length as the canvas even when it changes size

            /* Adjusts objects on screen when it changes size */
            // checks if the window changes width then it will readjust the width of objects and their location
            stage.widthProperty().addListener(observable -> {
                double factor= stage.getWidth()/pingPongController.getApp().getDimensionX(); // stores the height of the window
                // stores new width of window
                pingPongController.getApp().setDimensionX(stage.getWidth());
                // resizes and repositions the shape
                pingPongController.getApp().resizeX(factor);
                canvas.setWidth(dimensionX); // resizes the canvas so canvas will grow with objects
                canvas.drawGame(pingPongController.getApp());
            });
            // checks if the window changes height then it will readjust the height of objects and their location
            stage.heightProperty().addListener(observable -> {
                double factor= stage.getHeight()/pingPongController.getApp().getDimensionY(); // stores the height of the window
                // sets the dimension to the new height
                pingPongController.getApp().setDimensionY(stage.getHeight());
                // resizes and repositions the shape
                pingPongController.getApp().resizeY(factor);
                canvas.setHeight(dimensionY); // resizes the canvas so canvas will grow with objects
                canvas.drawGame(pingPongController.getApp());
            });

            stage.setScene(scene);
            stage.show();
        } catch(Exception e){
            e.printStackTrace();
        }
    }

    /**
     * This is what launches the program when the game is opened
     * @param args: arguments
     */
    public static void main(String[] args) {
        launch();
    }

    // GETTERS
    // games parts that the player uses

    /**
     *
     * @return racket1 object
     */
    public Racket getRacket1() {
        return racket1;
    }

    /**
     *
     * @return racket2 object
     */
    public Racket getRacket2() {
        return racket2;
    }

    /**
     *
     * @return ball object
     */
    public Ball getBall() {return ball;}

    /**
     *
     * @return player1 object
     */
    public Player getPlayer1(){return player1;}

    /**
     *
     * @return player2 object
     */
    public Player getPlayer2(){return player2;}

    /**
     *
     * @return the target score a player must get
     */
    public int getWinningScore(){return winningScore;}

    // dimensions
    /**
     *
     * @return width of the window
     */
    public double getDimensionX(){return dimensionX;}

    /**
     *
     * @return height of window
     */
    public double getDimensionY(){return dimensionY;}

    // SETTERS

    /**
     *
     * @param dimensionX the new width of the window
     */
    public void setDimensionX(double dimensionX) {this.dimensionX = dimensionX;}

    /**
     *
     * @param dimensionY the new height of the window
     */
    public void setDimensionY(double dimensionY) {this.dimensionY = dimensionY;}

    /**
     *
     * @param score the new target score for player to win
     */
    public void setWinningScore(int score){this.winningScore = score;}
}