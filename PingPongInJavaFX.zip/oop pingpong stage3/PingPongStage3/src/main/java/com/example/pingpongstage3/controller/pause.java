package com.example.pingpongstage3.controller;

import com.example.pingpongstage3.PingPongApplication;
import com.example.pingpongstage3.view.PingPongCanvas;
import javafx.event.EventHandler;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.KeyCode;

public class pause implements EventHandler<KeyEvent> {
    private boolean isPaused;
    private PingPongApplication game;

    /**
     * CONSTRUCTOR
     * @param isPaused checks if the game is set to pause
     * @param game PingPongApplication
     */
    public pause(boolean isPaused, PingPongApplication game) {
        this.isPaused = isPaused;
        this.game = game;
    }

    /**
     * checks if space is pressed then pauses or unpauses depending on the boolean status
     * @param keyEvent detects a key event occurring
     */
    @Override
    public void handle(KeyEvent keyEvent) {
        KeyCode key=keyEvent.getCode();
        // when space is pressed the game will pause. Space allows the players to pause the game quickly and easily
        if (KeyCode.SPACE.equals(key)) {
            if(isPaused){ // when the game plays
                isPaused = false;

            } else { // when the game pauses
                isPaused = true;
            }
        }
    }
}
