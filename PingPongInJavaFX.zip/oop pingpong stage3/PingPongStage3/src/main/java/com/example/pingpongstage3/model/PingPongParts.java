package com.example.pingpongstage3.model;

import com.example.pingpongstage3.view.PingPongCanvas;
import javafx.scene.paint.Color;

public class PingPongParts {
    public PingPongCanvas canvas;
    public double xPos = 0;
    public double yPos = 0;
    private Color color;

    /**
     * CONSTRUCTOR
     * @param xPos x position for rackets and ball
     * @param yPos y position for rackets and ball
     * @param color colour of rackets and ball
     */
    public PingPongParts(double xPos, double yPos, Color color){
        this.xPos = xPos;
        this.yPos = yPos;
        this.color = color;
    }

    // getters

    /**
     *
     * @return colour of object
     */
    public Color getColor() {
        return color;
    }

    // setters

    /**
     * sets the new x positions for each object
     * @param xPos new x position
     */
    public void setxPos(double xPos) {
        this.xPos = xPos;
    }
    /**
     * sets the new y positions for each object
     * @param yPos new y position
     */
    public void setyPos(double yPos) {
        this.yPos = yPos;
    }

    /**
     * sets new colour
     * @param color colour of object
     */
    public void setColor(Color color) {
        this.color = color;
    }

}
