package com.example.pingpongstage3.model;

public class Player {
    private int score = 0;
    private String name = "Player";

    /**
     * CONSTRUCTOR
     * @param score score that is earned when a goal is scored
     * @param name player's name
     */
    public Player(int score, String name){
        this.score = score;
        this.name = name;
    }

    /**
     *
     * @return a player's score
     */
    public int getScore(){return score;}

    /**
     * This updates everytime a player gets goal
     * @param newScore updated player score
     */
    public void setScore(int newScore){this.score = newScore;}

    /**
     *
     * @return name. name of the player
     */
    public String getName(){return name;}

    /**
     *
     * @param newName
     */
    public void setName(String newName){this.name = newName;}

}

