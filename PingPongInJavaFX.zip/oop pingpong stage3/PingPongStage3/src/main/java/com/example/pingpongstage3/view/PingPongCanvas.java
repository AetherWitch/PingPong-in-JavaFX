package com.example.pingpongstage3.view;

import com.example.pingpongstage3.PingPongApplication;
import com.example.pingpongstage3.model.Ball;
import com.example.pingpongstage3.model.Player;
import com.example.pingpongstage3.model.Racket;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class PingPongCanvas extends Canvas {
    /**
     *
     * @param width: width of screen
     * @param height: height of screen
     */
    public PingPongCanvas(double width, double height) {
        super(width, height);
    }

    /**
     * This draws the shapes that are always present and the background of the canvas from one method
     * @param game: PingPongApplication
     */
    public void drawGame(PingPongApplication game){
        GraphicsContext gc = this.getGraphicsContext2D();
        drawBackground(gc);
        drawBall(gc, game.getBall());
        drawRacket(gc, game.getRacket1());
        drawRacket(gc, game.getRacket2());
        drawName(this.getWidth()/3, (this.getHeight()/8)*7, gc, game.player1);
        drawName(this.getWidth()/2, (this.getHeight()/8)*7, gc, game.player2);

        resetSize(game);
    }

    /**
     * draws a ball on the screen
     * @param gc: graphics context
     * @param ball: ball object. uses x and y position and radius
     */
    private void drawBall(GraphicsContext gc, Ball ball){
        /**
         * This draws the ball
         */
        gc.setFill(ball.getColor());
        gc.fillOval(ball.xPos, ball.yPos, ball.getBallRadius(), ball.getBallRadius());
    }

    /**
     * This draws rackets that appear on the screen
     * @param gc: graphics context
     * @param racket: racket object. uses x and y position and radius
     */
    private void drawRacket(GraphicsContext gc, Racket racket){
        gc.setFill(racket.getColor());
        gc.fillRect(racket.xPos, racket.yPos, racket.getRacketWidth(), racket.getRacketHeight());
    }

    /**
     * This draws the name of the player and their score
     * @param x: x position
     * @param y: y position
     * @param gc: graphics context
     * @param player: player object. uses name and score
     */
    private void drawName(double x, double y, GraphicsContext gc, Player player){
        gc.setFill(Color.WHITE);
        String stringScore = Integer.toString(player.getScore());
        gc.setFont(Font.font(10));
        gc.fillText((player.getName() + ": " + stringScore), x, y);
    }

    /**
     * This displays the word 'GOAL' when ever a goal is scored
     * the colours change to add more excitement to getting a goal
     * @param x: x position
     * @param y: y position
     */
    public void drawGoalScored(double x, double y) {
        GraphicsContext gc = this.getGraphicsContext2D();

        for(int i = 0; i<4; i++){
            // loops through colours
            if(i == 0){
                gc.setFill(Color.RED);
            } else if(i == 1){
                gc.setFill(Color.YELLOW);
            } else if (i == 2) {
                gc.setFill(Color.GREEN);
            } else {
                gc.setFill(Color.BLUE);
            }
            gc.setFont(Font.font(30));
            gc.fillText(("GOAL"), x, y);
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                System.out.println("Goal Scored");
            }
        }
    }

    /**
     * This displays at the end of a game to show the winner
     * @param x: x position
     * @param y: y position
     * @param player: player object. uses name and score
     */
    public void drawWinner(double x, double y, Player player){
        GraphicsContext gc = this.getGraphicsContext2D();
        for(int i = 0; i<4; i++){

            if(i == 0){
                gc.setFill(Color.RED);
            } else if(i == 1){
                gc.setFill(Color.YELLOW);
            } else if (i == 2) {
                gc.setFill(Color.GREEN);
            } else {
                gc.setFill(Color.BLUE);
            }
            gc.setFont(Font.font(30));
            String stringScore = Integer.toString(player.getScore());
            gc.fillText((player.getName() + " WINS with " + stringScore), x, y);
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                System.out.println(player.getName() + "WINS");
            }
        }
    }

    // canvas size

    /**
     * This resets the size of the canvas
     * @param game: PingPongApplication
     */
    private void resetSize(PingPongApplication game){
        game.setDimensionX(this.getWidth());
        game.setDimensionY(this.getHeight());
        this.setWidth(game.getDimensionX());
        this.setHeight(game.getDimensionY());
    }

    /**
     * This fills in the background of the canvas
     * @param gc: graphics context
     */
    private void drawBackground(GraphicsContext gc){
        gc.setFill(Color.BLACK);
        gc.clearRect(0, 0, this.getWidth(), this.getHeight());
        gc.fillRect(0, 0, this.getWidth(), this.getHeight());
    }
}
