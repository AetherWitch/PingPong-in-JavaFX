package com.example.pingpongstage3.controller;

import com.example.pingpongstage3.PingPongApplication;
import com.example.pingpongstage3.model.Ball;
import com.example.pingpongstage3.model.Player;
import com.example.pingpongstage3.model.Racket;
import com.example.pingpongstage3.view.PingPongCanvas;
import javafx.scene.paint.Color;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BallManagerTest {
    /**
     * Tests if player1 gets a point when the ball hits the right wall
     */
    @Test
    void player1Scores() {
        PingPongApplication game = new PingPongApplication();
        Ball ball = new Ball(game.getDimensionX()/2, game.getDimensionY()/2, 30, 1, Color.PURPLE, 3, game);
        assertFalse(ball.xPos<=0);
        ball.setxPos(0);
        assertTrue(ball.xPos<=0);
    }

    /**
     * Tests if player2 gets a point when the ball hits the left wall
     */
    @Test
    void player2Scores() {
        PingPongCanvas canvas = new PingPongCanvas(400,600);
        Ball ball = new Ball(canvas.getWidth()/2, canvas.getHeight()/2, 30, 1, Color.PURPLE, 3, null);
        assertFalse(ball.xPos>=canvas.getWidth());
        ball.setxPos(canvas.getWidth());
        assertTrue(ball.xPos>=canvas.getWidth());
    }

    /**
     * Tests if when a player gets the win target the game ends
     */
    @Test
    void checkEndOfGame() {
        Player player1 = new Player(3, "Player1");
        Player player2 = new Player(0, "Player1");
        int maxScore= Math.max(player1.getScore(), player2.getScore());
        assertEquals(3, maxScore);
    }

    /**
     * checks if the ball collides with the left racket
     */
    @Test
    void hitLeftRacket(){
        PingPongCanvas canvas = new PingPongCanvas(400,600);
        Racket racket1 = new Racket(0, canvas.getHeight()/2, 30, 20, Color.PURPLE);
        Ball ball = new Ball(canvas.getWidth()/2, canvas.getHeight()/2, 3, 1, Color.PURPLE, 3, null);
        assertFalse(ball.xPos + ball.getBallRadius() <= racket1.getRacketWidth()/2);
        ball.setxPos(0);
        assertTrue(ball.xPos + ball.getBallRadius() <= racket1.getRacketWidth()/2);
    }
    /**
     * checks if the ball collides with the right racket
     */
    @Test
    void hitRightRacket(){
        PingPongCanvas canvas = new PingPongCanvas(400,600);
        Racket racket2 = new Racket(0, canvas.getHeight()/2, 30, 20, Color.PURPLE);
        Ball ball = new Ball(canvas.getWidth()/2, canvas.getHeight()/2, 3, 1, Color.PURPLE, 3, null);
        assertFalse(ball.xPos + ball.getBallRadius() >= canvas.getWidth() - racket2.getRacketWidth());
        ball.setxPos(canvas.getWidth());
        assertTrue(ball.xPos + ball.getBallRadius() >= canvas.getWidth() - racket2.getRacketWidth());
    }

    /**
     * checks if the ball collides with the bottom wall
     */
    @Test
    void hitBottom(){
        PingPongCanvas canvas = new PingPongCanvas(400,600);
        Ball ball = new Ball(canvas.getWidth()/2, canvas.getHeight()/2, 3, 1, Color.PURPLE, 3, null);
        assertFalse(ball.yPos + ball.getBallRadius() >= canvas.getHeight());
        ball.setyPos(canvas.getHeight());
        assertTrue(ball.yPos + ball.getBallRadius() >= canvas.getHeight());
    }

    /**
     * checks if the ball collides with the top wall
     */
    @Test
    void hitTop(){
        PingPongCanvas canvas = new PingPongCanvas(400,600);
        Ball ball = new Ball(canvas.getWidth()/2, canvas.getHeight()/2, 3, 1, Color.PURPLE, 3, null);
        assertFalse(ball.yPos + ball.getBallRadius() <= 0);
        ball.setyPos(0);
        assertTrue(ball.yPos + ball.getBallRadius() >= 0);
    }
}