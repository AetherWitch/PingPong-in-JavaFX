package com.example.pingpongstage3;

import javafx.scene.control.MenuItem;

public class PingPongGameMenu {
    private final PingPongMenuListener menuListener;
    private MenuItem menuItemExit;

    /**
     *
     * @param menuListener MenuListener
     */
    public PingPongGameMenu(PingPongMenuListener menuListener){
        this.menuListener = menuListener;
    }

    /**
     * when the item is clicked it exits the game
     */
    private void handleClicking(){
        menuItemExit.setOnAction(e->menuListener.setExit());
    }
}
