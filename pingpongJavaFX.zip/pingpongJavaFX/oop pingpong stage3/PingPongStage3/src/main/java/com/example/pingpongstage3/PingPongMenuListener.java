package com.example.pingpongstage3;

import javafx.application.Platform;

public class PingPongMenuListener {
    private PingPongApplication game;
    public PingPongMenuListener(PingPongApplication game){this.game = game;}

    // player
    public void setPlayer1Name(){
        game.player1.setName("Player1");
    }
    public void setPlayer2Name() {
        game.player2.setName("Player2");
    }
    // ball Speed
    /**
     * sets the ball speed so that the ball will move across the screen slowly
     */
    public void setBallSpeedSlow(){
        game.ball.setBallSpeed(1);
    }
    /**
     * sets the ball speed so that the ball will move across the screen at a medium pace
     */
    public void setBallSpeedNormal(){
        game.ball.setBallSpeed(2);
    }

    /**
     * sets the ball speed so that the ball will move across the screen very fast
     */
    public void setBallSpeedFast(){
        game.ball.setBallSpeed(5);
    }

    // Racket size
    /**
     * Sets both rackets to be small size
     */
    public void setRacketSizeSmall(){
        game.racket1.setRacketHeight(30);
        game.racket1.setRacketWidth(20);

        game.racket2.setRacketWidth(20);
        game.racket2.setRacketHeight(30);
        game.canvas.drawGame(game);
    }

    /**
     * sets both rackets to be a medium size
     */
    public void setRacketSizeMedium(){
        game.racket1.setRacketHeight(50);
        game.racket1.setRacketWidth(30);

        game.racket2.setRacketWidth(30);
        game.racket2.setRacketHeight(50);
        game.canvas.drawGame(game);
    }

    /**
     * sets both rackets to be a large size
     */
    public void setRacketSizeLarge(){
        game.racket1.setRacketHeight(200);
        game.racket1.setRacketWidth(100);

        game.racket2.setRacketWidth(100);
        game.racket2.setRacketHeight(200);
        game.canvas.drawGame(game);
    }

    // winning score
    /**
     * Sets the score one player must reach to win to be 3
     */
    public void setWinningScore3(){
        game.setWinningScore(3);
    }
    /**
     * Sets the score one player must reach to win to be 5
     */
    public void setWinningScore5(){
        game.setWinningScore(5);
    }
    /**
     * Sets the score one player must reach to win to be 10
     */
    public void setWinningScore10(){
        game.setWinningScore(10);
    }

    // ball speed change
    /**
     * sets the amount of times the ball speed will increase to be 0 times
     */
    public void changeBallSpeed0(){
        game.ball.setGetBallSpeedChange(0);
    }
    /**
     * sets the amount of times the ball speed will increase to be 3 times
     */
    public void changeBallSpeed3(){
        game.ball.setGetBallSpeedChange(3);
    }
    /**
     * sets the amount of times the ball will increase to be 5 times
     */
    public void changeBallSpeed5(){
        game.ball.setGetBallSpeedChange(5);
    }

    // restart
    /**
     * restarts the game
     * so both rackets are set back to the middle on their respective sides
     * the ball is placed in the middle
     * the player scores are reset to 0
     */
    public void restart(){
        // ball
        game.ball.setxPos(game.getDimensionX()/2);
        game.ball.setyPos(game.getDimensionY()/2);

        // racket 1 LEFT
        game.racket1.setyPos(game.getDimensionY()/2);
        game.racket1.setxPos(0);

        // racket 2 RIGHT
        game.racket2.setyPos(game.getDimensionY()/2);
        game.racket2.setxPos(game.dimensionX - game.racket2.getRacketWidth());

        // player scores
        game.player1.setScore(0);
        game.player2.setScore(0);
    }
    
    // exit
    /**
     * the application closes
     */
    public void setExit(){
        Platform.exit();
    }
}
