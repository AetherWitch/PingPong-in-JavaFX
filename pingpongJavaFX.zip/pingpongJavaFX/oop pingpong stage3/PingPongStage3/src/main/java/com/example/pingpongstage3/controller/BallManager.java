package com.example.pingpongstage3.controller;

import com.example.pingpongstage3.PingPongApplication;
import com.example.pingpongstage3.PingPongMenuListener;
import com.example.pingpongstage3.model.Ball;
import com.example.pingpongstage3.model.Player;
import com.example.pingpongstage3.view.PingPongCanvas;

public class BallManager implements Runnable{
    private PingPongApplication game;
    private PingPongCanvas canvas;

    /**
     * CONSTRUCTOR
     * @param c: PingPongApplication
     * @param canvas: where the ball will be drawn from
     */
    public BallManager(PingPongApplication c, PingPongCanvas canvas) {
        this.game=c;
        this.canvas=canvas;
    }


    @Override
    public void run() {
        /**
         * This is what runs the thread
         * that controls how the ball moves during the game
         *
         * <br> manages when speed of the ball should increase
         * <br>detects collision on the top or bottom wall
         * <br> detects collision to rackets
         * <br> detects when player gets a point and manages when goal message should appear
         * <br> detects when a player wins and when winner message appears
         */
        Ball ball = game.getBall();
        Player player1 = game.getPlayer1();
        Player player2 = game.getPlayer2();

        int ballBounceCount = 0;
        int speedChangeCount = 0;

        // set the starting direction
        int direction = 4;
        while(!Thread.currentThread().isInterrupted()) {
            try {
                Thread.sleep(10);

                // the speed of the ball will change after X amount of bounces
                if(speedChangeCount < ball.getBallSpeedChange()){
                    if (ballBounceCount%2 == 0){
                        ball.setBallSpeed(ball.ballSpeed++);
                        speedChangeCount++;
                    }
                }

                // 1 is down: left
                // 2 is down: right
                // 3 is up: left
                // 4 is up: right

                // changes direction when wall is hit
                /* BALL HITS TOP OR BOTTOM OF SCREEN */
                if(ball.yPos <= 0){ // hits TOP - ball must go down
                    if(direction == 3){
                        direction = 1;// down left
                    } else {
                        direction = 2;// up right
                    }
                }
                if(ball.yPos + ball.getBallRadius() >= game.dimensionY - ball.getBallRadius()){ // hits BOTTOM - ball must go up
                    if(direction == 2){
                        direction = 4;// down right
                    } else {
                        direction = 3;// down left
                    }
                }

                /* RACKET COLLISION */
                // ball hits LEFT paddle
                if(ball.xPos <= game.racket1.getRacketWidth()){
                    if((ball.yPos + ball.getBallRadius() > game.racket1.yPos) && (ball.yPos + ball.getBallRadius() < game.racket1.yPos + game.racket1.getRacketHeight())){ // if ball ypos is between top and bottom of paddle
                        if(direction == 3){
                            direction = 4;// up right
                        } else {
                            direction = 2;// down right
                        }
                        ballBounceCount++;
                    }
                }

                // ball hits RIGHT paddle
                if(ball.xPos > game.dimensionX - (game.racket1.getRacketWidth()*2)){
                    if((ball.yPos + ball.getBallRadius() > game.racket2.yPos) && (ball.yPos + ball.getBallRadius() < game.racket2.yPos + game.racket2.getRacketHeight())) { // if ball ypos is between top and bottom of paddle
                        if(direction == 4){
                            direction = 3;// up left
                        } else{
                            direction = 1;// down left
                        }
                        ballBounceCount++;
                    }
                }

                /* BALL HITS WALL AND GOAL IS SCORED */
                if(ball.xPos + ball.getBallRadius() >= game.dimensionX - game.racket2.getRacketWidth()/2){ // hits RIGHT - ball must go left
                    // ball is sent back to the center
                    ball.xPos = game.dimensionX/2;
                    ball.yPos = game.dimensionY/2;
                    // ball direction goes to the direction of the winner's paddle
                    direction = 3;

                    // text appears and pauses the ball to show that a goal has been scored (p1)
                    canvas.drawGoalScored(game.dimensionX/2, game.dimensionY/2);

                    // player 1 score is updated
                    player1.setScore(player1.getScore()+1);
                }

                if(ball.xPos + ball.getBallRadius() <= game.racket1.getRacketWidth()/2){ // hits LEFT - ball must go right
                    // ball is sent back to the center
                    ball.xPos = game.dimensionX/2;
                    ball.yPos = game.dimensionY/2;
                    // ball direction goes to the direction of the winner's paddle (p2)
                    direction = 4;

                    // text appears and pauses the ball to show that a goal has been scored
                    canvas.drawGoalScored(game.dimensionX/2, game.dimensionY/2);

                    // player 2 score is updated
                    player2.setScore(player2.getScore()+1);
                }

                // ball moves
                ball.move(direction);

                /* WINNER AND END OF GAME */
                if(player1.getScore() >= game.winningScore){
                    canvas.drawWinner(game.getDimensionX()/2, game.getDimensionY()/4, player1);

                    // RESTARTS THE GAME
                    // ball
                    game.ball.setxPos(game.getDimensionX()/2);
                    game.ball.setyPos(game.getDimensionY()/2);

                    // racket 1 LEFT
                    game.racket1.setyPos(game.getDimensionY()/2);
                    game.racket1.setxPos(0);

                    // racket 2 RIGHT
                    game.racket2.setyPos(game.getDimensionY()/2);
                    game.racket2.setxPos(game.dimensionX - game.racket2.getRacketWidth());

                    // player scores
                    game.player1.setScore(0);
                    game.player2.setScore(0);
                } else if (player2.getScore() >= game.winningScore){
                    canvas.drawWinner(game.getDimensionX()/2, game.getDimensionY()/4, player1);

                    // RESTARTS THE GAME
                    // ball
                    game.ball.setxPos(game.getDimensionX()/2);
                    game.ball.setyPos(game.getDimensionY()/2);

                    // racket 1 LEFT
                    game.racket1.setyPos(game.getDimensionY()/2);
                    game.racket1.setxPos(0);

                    // racket 2 RIGHT
                    game.racket2.setyPos(game.getDimensionY()/2);
                    game.racket2.setxPos(game.dimensionX - game.racket2.getRacketWidth());

                    // player scores
                    game.player1.setScore(0);
                    game.player2.setScore(0);
                }

                // canvas redraws to update the movement
                canvas.drawGame(game);


            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }

        }
    }
}
