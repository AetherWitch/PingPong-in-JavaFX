package com.example.pingpongstage3.controller;

import com.example.pingpongstage3.PingPongApplication;

public class PingPongController {
    public PingPongApplication app;

    /**
     *
     * @param app PingPongApplication
     */
    public PingPongController(PingPongApplication app){
        this.app = app;
    }

    /**
     *
     * @return the PingPongApplication
     */
    public PingPongApplication getApp() {return app;}
}