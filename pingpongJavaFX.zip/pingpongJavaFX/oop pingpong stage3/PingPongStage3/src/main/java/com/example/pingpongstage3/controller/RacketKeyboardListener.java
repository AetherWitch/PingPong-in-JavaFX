package com.example.pingpongstage3.controller;

import com.example.pingpongstage3.PingPongApplication;
import com.example.pingpongstage3.view.PingPongCanvas;
import javafx.event.EventHandler;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.KeyCode;

public class RacketKeyboardListener implements EventHandler<KeyEvent> {
    private PingPongApplication game;
    private PingPongCanvas canvas;

    /**
     * CONSTRUCTOR
     * @param game2 PingPongApplication. It is named game2 to allow it to run separately from the ball
     * @param canvas the class used to draw everything in the game
     */
    public RacketKeyboardListener(PingPongApplication game2, PingPongCanvas canvas) {
        this.game =game2;
        this.canvas =canvas;
    }

    /**
     * This method enables players to move their rackets up and down
     * <br> W or S is controlled by Player1 on the left
     * <br> Up or Down is contolled by Player2 on the right
     * @param keyEvent detects when a key is pressed
     */
    @Override
    public void handle(KeyEvent keyEvent) {
        //System.out.println(keyEvent);
        KeyCode key=keyEvent.getCode();
        // player 2 racket movement
        if (KeyCode.UP.equals(key)) {
            game.racket2.moveUp();
            canvas.drawGame(game);
        }
        if (KeyCode.DOWN.equals(key)) {
            game.racket2.moveDown();
            canvas.drawGame(game);
        }
        // player 1 racket movement
        if (KeyCode.W.equals(key)) {
            game.racket1.moveUp();
            canvas.drawGame(game);
        }
        if (KeyCode.S.equals(key)) {
            game.racket1.moveDown();
            canvas.drawGame(game);
        }
    }
}
