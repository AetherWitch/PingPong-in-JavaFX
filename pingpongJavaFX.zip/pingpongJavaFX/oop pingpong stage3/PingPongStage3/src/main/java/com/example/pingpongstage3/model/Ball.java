package com.example.pingpongstage3.model;
import com.example.pingpongstage3.PingPongApplication;
import com.example.pingpongstage3.view.PingPongCanvas;
import javafx.scene.paint.Color;

public class Ball extends PingPongParts {
    private double ballRadius;
    public int ballSpeed;
    private int ballSpeedChange;
    private PingPongCanvas canvas;
    private PingPongApplication game;

    /**
     * CONSTRUCTOR
     * @param xPos ball's x position
     * @param yPos ball's y position
     * @param ballRadius the radius of the ball. determines the size of the ball
     * @param ballSpeed speed of the ball
     * @param colour the colour of the ball
     * @param ballSpeedChange the amount of times the ball will increase speed
     * @param game PingPongApplication
     */
    public Ball(double xPos, double yPos, double ballRadius, int ballSpeed, Color colour, int ballSpeedChange, PingPongApplication game) {
        super(xPos, yPos, colour);
        this.ballRadius = ballRadius;
        this.ballSpeed = ballSpeed;
        this.ballSpeedChange = ballSpeedChange;
        this.game = game;
    }

    /**
     *
     * @return the radius of the ball
     */
    public double getBallRadius(){return this.ballRadius;}

    /**
     *
     * @return the speed of the ball
     */
    public int getBallSpeed(){return ballSpeed;}

    /**
     *
     * @return the amount of times the ball will change speed
     */
    public int getBallSpeedChange(){return ballSpeedChange;}

    // setters

    /**
     * sets the radius of the ball
     * @param ballRadius the new radius of the ball
     */
    public void setBallRadius(double ballRadius) {this.ballRadius = ballRadius;}

    /**
     * sets speed of ball
     * @param newSpeed the new speed of the ball
     */
    public void setBallSpeed(int newSpeed){this.ballSpeed = newSpeed;}

    /**
     *  changes amount of times the ball will change speed
     * @param newBallSpeedChange new amount of times the ball will change speed
     */
    public void setGetBallSpeedChange(int newBallSpeedChange) {this.ballSpeedChange = newBallSpeedChange;}

    // resize
    /**
     * resizes the ball by x-axis
     * @param factor the factor it needs to be multiplied by to change size
     */
    public void resizeX(double factor) {
        this.xPos = this.xPos*factor;
        setBallRadius(this.ballRadius*factor);
    }
    /**
     * resizes the ball by y-axis
     * @param factor the factor it needs to be multiplied by to change size
     */
    public void resizeY(double factor) {
        this.yPos = this.yPos*(factor);
        setBallRadius(this.ballRadius*((factor/3)*2));
    }

    /**
     * this method determines the x and y position of the ball which updates in the thread in BallManager
     * @param direction direction changes in the BallManager class. it determines which way the ball will go
     *                  <br> 1 is down and left
     *                  <br> 2 is down and right
     *                  <br> 3 is up and left
     *                  <br> 4 is up and right
     */
    public void move(int direction){
        // y++ is down
        // y-- is up
        switch(direction){
            // when var is changed direction will be changed
            case 1: // down left
                this.yPos = this.yPos + ballSpeed;
                this.xPos = this.xPos- ballSpeed;
                break;
            case 2: // down right
                this.yPos = this.yPos+ballSpeed;
                this.xPos = this.xPos+ballSpeed;
                break;
            case 3: // up left
                this.yPos = this.yPos-ballSpeed;
                this.xPos = this.xPos-ballSpeed;
                break;
            case 4: // up right
                this.yPos = this.yPos-ballSpeed;
                this.xPos = this.xPos+ballSpeed;
                break;
        }
    }
}
