package com.example.pingpongstage3.model;

import javafx.scene.paint.Color;

public class Racket extends PingPongParts {
    private double racketHeight;
    private double racketWidth;

    /**
     * CONSTRUCTOR
     * @param xPos x position
     * @param yPos y position
     * @param racketHeight height of the rackets
     * @param racketWidth width of the rackets
     * @param colour colour of a racket
     */
    public Racket(double xPos, double yPos, double racketHeight, double racketWidth, Color colour){
        super(xPos, yPos, colour);
        this.racketHeight = racketHeight;
        this.racketWidth = racketWidth;
    }

    // getters

    /**
     *
     * @return height of the racket
     */
    public double getRacketHeight(){return this.racketHeight;}

    /**
     *
     * @return width of the racket
     */
    public double getRacketWidth(){return this.racketWidth;}

    // setters

    /**
     *
     * @param newHeight updated racket height
     */
    public void setRacketHeight(double newHeight){this.racketHeight = newHeight;}

    /**
     *
     * @param newWidth updated racket width
     */
    public void setRacketWidth(double newWidth){this.racketWidth = newWidth;}

    // resizing
    /**
     *
     * @param factor amount racket width must be multiplied by to proportionally change size with window
     */
    public void resizeX(double factor) {
        this.xPos = this.xPos*factor; //position
        setRacketWidth(this.racketWidth*factor); // size
    }
    /**
     *
     * @param factor amount racket height must be multiplied by to proportionally change size with window
     */
    public void resizeY(double factor) {
        this.yPos = this.yPos*factor; // position
        setRacketHeight(this.racketHeight*factor); // size
    }

    /**
     * racket will move up the screen
     */
    public void moveUp(){
        this.yPos = this.yPos-10;
    }

    /**
     * racket will move down the screen
     */
    public void moveDown(){
        this.yPos = this.yPos+10;
    }
}

