package com.example.pingpongstage3.model;

public interface Resizable {
    public void resizeX(double factor);
    public void resizeY(double factor);
}
