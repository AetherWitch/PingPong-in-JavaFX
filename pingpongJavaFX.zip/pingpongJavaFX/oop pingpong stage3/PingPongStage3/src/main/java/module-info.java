module com.example.pingpongstage1 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.pingpongstage3 to javafx.fxml;
    exports com.example.pingpongstage3;
    exports com.example.pingpongstage3.model;
    opens com.example.pingpongstage3.model to javafx.fxml;
    exports com.example.pingpongstage3.controller;
    opens com.example.pingpongstage3.controller to javafx.fxml;
    exports com.example.pingpongstage3.view;
    opens com.example.pingpongstage3.view to javafx.fxml;
}